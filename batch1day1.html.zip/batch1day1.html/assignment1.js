console.log("hello world");
console.log({apple:fruit,cabbage: vegetable});
console.error("an error has ocurred");
console.warn("this is your  first warning");
console.clear();
console.time(hello);
    console.error("this is an error");
    console.error('you have made an error');
    console.warn("this is a warning");
console.timeEnd(hello);
console.table({car:rolls royce,bike:harley davidson});
for(let i=0;i<5;i++)
{
    console.count(i)
}
console.group(hiii);
    console.error("this is an error");
    console.error('you have made an error');
    console.warn("this is a warning");
console.groupEnd(hiii);
console.log('%c custom Message','color:Red');